import { pgTable, text, serial, integer, boolean, timestamp, real, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const mediaItems = pgTable("media_items", {
  id: serial("id").primaryKey(),
  filename: text("filename").notNull(),
  originalName: text("original_name").notNull(),
  mimeType: text("mime_type").notNull(),
  size: integer("size").notNull(),
  type: text("type").notNull(), // 'image' or 'video'
  latitude: real("latitude"),
  longitude: real("longitude"),
  locationName: text("location_name"),
  locationAddress: text("location_address"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const aiAnalysis = pgTable("ai_analysis", {
  id: serial("id").primaryKey(),
  mediaItemId: integer("media_item_id").references(() => mediaItems.id).notNull(),
  analysisText: text("analysis_text").notNull(),
  detectedObjects: jsonb("detected_objects").$type<string[]>(),
  detectedIssues: jsonb("detected_issues").$type<{
    type: string;
    severity: 'low' | 'medium' | 'high' | 'critical';
    description: string;
    confidence: number;
  }[]>(),
  confidence: real("confidence").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  type: text("type").notNull(),
  status: text("status").notNull().default('draft'),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  includeImages: boolean("include_images").default(true),
  includeIssues: boolean("include_issues").default(true),
  includeLocation: boolean("include_location").default(false),
  content: jsonb("content").$type<{
    summary: string;
    mediaItems: number[];
    issues: number[];
  }>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertMediaItemSchema = createInsertSchema(mediaItems).omit({
  id: true,
  createdAt: true,
});

export const insertAiAnalysisSchema = createInsertSchema(aiAnalysis).omit({
  id: true,
  createdAt: true,
}).extend({
  detectedObjects: z.array(z.string()).optional(),
  detectedIssues: z.array(z.object({
    type: z.string(),
    severity: z.enum(['low', 'medium', 'high', 'critical']),
    description: z.string(),
    confidence: z.number()
  })).optional()
});

export const insertReportSchema = createInsertSchema(reports).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  content: z.object({
    summary: z.string(),
    mediaItems: z.array(z.number()),
    issues: z.array(z.number())
  }).optional()
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertMediaItem = z.infer<typeof insertMediaItemSchema>;
export type MediaItem = typeof mediaItems.$inferSelect;

export type InsertAiAnalysis = z.infer<typeof insertAiAnalysisSchema>;
export type AiAnalysis = typeof aiAnalysis.$inferSelect;

export type InsertReport = z.infer<typeof insertReportSchema>;
export type Report = typeof reports.$inferSelect;

export type MediaWithAnalysis = MediaItem & {
  analysis?: AiAnalysis;
};
