import { 
  users, 
  mediaItems, 
  aiAnalysis, 
  reports,
  type User, 
  type InsertUser,
  type MediaItem,
  type InsertMediaItem,
  type AiAnalysis,
  type InsertAiAnalysis,
  type Report,
  type InsertReport,
  type MediaWithAnalysis
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, lte } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Media operations
  createMediaItem(mediaItem: InsertMediaItem): Promise<MediaItem>;
  getMediaItem(id: number): Promise<MediaWithAnalysis | undefined>;
  getAllMediaItems(): Promise<MediaWithAnalysis[]>;
  getMediaItemsByDateRange(startDate: Date, endDate: Date): Promise<MediaWithAnalysis[]>;
  
  // AI Analysis operations
  createAiAnalysis(analysis: InsertAiAnalysis): Promise<AiAnalysis>;
  getAiAnalysisByMediaId(mediaItemId: number): Promise<AiAnalysis | undefined>;
  
  // Report operations
  createReport(report: InsertReport): Promise<Report>;
  getReport(id: number): Promise<Report | undefined>;
  getAllReports(): Promise<Report[]>;
  updateReport(id: number, updates: Partial<InsertReport>): Promise<Report>;
  
  // Statistics
  getMediaStats(): Promise<{
    imagesCount: number;
    videosCount: number;
    issuesCount: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async createMediaItem(mediaItem: InsertMediaItem): Promise<MediaItem> {
    const [item] = await db
      .insert(mediaItems)
      .values(mediaItem)
      .returning();
    return item;
  }

  async getMediaItem(id: number): Promise<MediaWithAnalysis | undefined> {
    const [item] = await db
      .select()
      .from(mediaItems)
      .where(eq(mediaItems.id, id));
    
    if (!item) return undefined;

    const [analysis] = await db
      .select()
      .from(aiAnalysis)
      .where(eq(aiAnalysis.mediaItemId, id));

    return {
      ...item,
      analysis: analysis || undefined
    };
  }

  async getAllMediaItems(): Promise<MediaWithAnalysis[]> {
    const items = await db
      .select()
      .from(mediaItems)
      .orderBy(desc(mediaItems.createdAt));

    const analyses = await db.select().from(aiAnalysis);
    
    return items.map(item => ({
      ...item,
      analysis: analyses.find(a => a.mediaItemId === item.id)
    }));
  }

  async getMediaItemsByDateRange(startDate: Date, endDate: Date): Promise<MediaWithAnalysis[]> {
    const items = await db
      .select()
      .from(mediaItems)
      .where(
        and(
          gte(mediaItems.createdAt, startDate),
          lte(mediaItems.createdAt, endDate)
        )
      )
      .orderBy(desc(mediaItems.createdAt));

    const mediaIds = items.map(item => item.id);
    const analyses = await db
      .select()
      .from(aiAnalysis)
      .where(eq(aiAnalysis.mediaItemId, mediaIds[0])); // This will need to be improved for multiple IDs

    return items.map(item => ({
      ...item,
      analysis: analyses.find(a => a.mediaItemId === item.id)
    }));
  }

  async createAiAnalysis(analysis: InsertAiAnalysis): Promise<AiAnalysis> {
    const [result] = await db
      .insert(aiAnalysis)
      .values({
        mediaItemId: analysis.mediaItemId,
        analysisText: analysis.analysisText,
        confidence: analysis.confidence,
        detectedObjects: analysis.detectedObjects || [],
        detectedIssues: analysis.detectedIssues || []
      })
      .returning();
    return result;
  }

  async getAiAnalysisByMediaId(mediaItemId: number): Promise<AiAnalysis | undefined> {
    const [analysis] = await db
      .select()
      .from(aiAnalysis)
      .where(eq(aiAnalysis.mediaItemId, mediaItemId));
    return analysis || undefined;
  }

  async createReport(report: InsertReport): Promise<Report> {
    const [result] = await db
      .insert(reports)
      .values({
        title: report.title,
        type: report.type,
        status: report.status || 'draft',
        startDate: report.startDate,
        endDate: report.endDate,
        includeImages: report.includeImages,
        includeIssues: report.includeIssues,
        includeLocation: report.includeLocation,
        content: report.content || { summary: '', mediaItems: [], issues: [] }
      })
      .returning();
    return result;
  }

  async getReport(id: number): Promise<Report | undefined> {
    const [report] = await db
      .select()
      .from(reports)
      .where(eq(reports.id, id));
    return report || undefined;
  }

  async getAllReports(): Promise<Report[]> {
    return await db
      .select()
      .from(reports)
      .orderBy(desc(reports.createdAt));
  }

  async updateReport(id: number, updates: Partial<InsertReport>): Promise<Report> {
    const updateData: any = {
      updatedAt: new Date()
    };
    
    if (updates.title !== undefined) updateData.title = updates.title;
    if (updates.type !== undefined) updateData.type = updates.type;
    if (updates.status !== undefined) updateData.status = updates.status;
    if (updates.startDate !== undefined) updateData.startDate = updates.startDate;
    if (updates.endDate !== undefined) updateData.endDate = updates.endDate;
    if (updates.includeImages !== undefined) updateData.includeImages = updates.includeImages;
    if (updates.includeIssues !== undefined) updateData.includeIssues = updates.includeIssues;
    if (updates.includeLocation !== undefined) updateData.includeLocation = updates.includeLocation;
    if (updates.content !== undefined) updateData.content = updates.content;

    const [report] = await db
      .update(reports)
      .set(updateData)
      .where(eq(reports.id, id))
      .returning();
    return report;
  }

  async getMediaStats(): Promise<{
    imagesCount: number;
    videosCount: number;
    issuesCount: number;
  }> {
    const allMedia = await db.select().from(mediaItems);
    const allAnalyses = await db.select().from(aiAnalysis);
    
    const imagesCount = allMedia.filter(item => item.type === 'image').length;
    const videosCount = allMedia.filter(item => item.type === 'video').length;
    const issuesCount = allAnalyses.reduce((count, analysis) => {
      return count + (analysis.detectedIssues?.length || 0);
    }, 0);

    return {
      imagesCount,
      videosCount,
      issuesCount
    };
  }
}

export const storage = new DatabaseStorage();
