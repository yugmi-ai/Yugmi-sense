import * as fs from "fs";
import { GoogleGenAI } from "@google/genai";

// This API key is from Gemini Developer API Key, not vertex AI API Key
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function analyzeImage(imagePath: string): Promise<string> {
    try {
        const imageBytes = fs.readFileSync(imagePath);

        const contents = [
            {
                inlineData: {
                    data: imageBytes.toString("base64"),
                    mimeType: "image/jpeg",
                },
            },
            `Analyze this construction/inspection image in detail. Focus on:
            1. Structural elements (foundation, walls, beams, supports)
            2. Electrical components (panels, wiring, outlets)
            3. Plumbing (pipes, fixtures, connections)
            4. Building materials (concrete, steel, wood)
            5. Safety hazards or structural issues
            6. Cracks, damage, or defects
            7. Code compliance concerns
            
            Provide a detailed analysis describing what you see, including any potential issues, their severity, and recommendations.`,
        ];

        const response = await ai.models.generateContent({
            model: "gemini-2.5-pro",
            contents: contents,
        });

        return response.text || "Unable to analyze image";
    } catch (error) {
        console.error('Gemini image analysis error:', error);
        throw new Error(`Failed to analyze image: ${error}`);
    }
}

export async function analyzeVideo(videoPath: string): Promise<string> {
    try {
        const videoBytes = fs.readFileSync(videoPath);

        const contents = [
            {
                inlineData: {
                    data: videoBytes.toString("base64"),
                    mimeType: "video/mp4",
                },
            },
            `Analyze this construction/inspection video in detail. Focus on:
            1. Structural elements and their condition
            2. Construction progress or inspection activities
            3. Equipment and machinery visible
            4. Safety procedures being followed
            5. Any visible defects, damage, or issues
            6. Workflow and process observations
            7. Environmental conditions
            
            Provide a comprehensive analysis of what you observe throughout the video, noting any concerns or recommendations.`,
        ];

        const response = await ai.models.generateContent({
            model: "gemini-2.5-pro",
            contents: contents,
        });

        return response.text || "Unable to analyze video";
    } catch (error) {
        console.error('Gemini video analysis error:', error);
        throw new Error(`Failed to analyze video: ${error}`);
    }
}
