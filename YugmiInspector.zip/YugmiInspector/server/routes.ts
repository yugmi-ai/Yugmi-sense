import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import path from "path";
import fs from "fs";
import { analyzeImage, analyzeVideo } from "./gemini";
import { insertMediaItemSchema, insertReportSchema } from "@shared/schema";

// Configure multer for file uploads
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif|mp4|mov|avi/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only images and videos are allowed.'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Media upload endpoint
  app.post('/api/media/upload', upload.single('media'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'No file uploaded' });
      }

      const { latitude, longitude, locationName, locationAddress } = req.body;
      
      const mediaType = req.file.mimetype.startsWith('image/') ? 'image' : 'video';
      
      // Create media item record
      const mediaItem = await storage.createMediaItem({
        filename: req.file.filename,
        originalName: req.file.originalname,
        mimeType: req.file.mimetype,
        size: req.file.size,
        type: mediaType,
        latitude: latitude ? parseFloat(latitude) : undefined,
        longitude: longitude ? parseFloat(longitude) : undefined,
        locationName: locationName || undefined,
        locationAddress: locationAddress || undefined,
      });

      // Perform AI analysis
      try {
        let analysisResult: string;
        let detectedObjects: string[] = [];
        let detectedIssues: any[] = [];
        let confidence = 0;

        if (mediaType === 'image') {
          analysisResult = await analyzeImage(req.file.path);
        } else {
          analysisResult = await analyzeVideo(req.file.path);
        }

        // Parse AI analysis to extract objects and issues
        // This is a simplified parsing - in production, you'd want more sophisticated parsing
        if (analysisResult.toLowerCase().includes('crack')) {
          detectedIssues.push({
            type: 'structural_crack',
            severity: 'critical',
            description: 'Visible crack detected in structure',
            confidence: 0.89
          });
        }

        if (analysisResult.toLowerCase().includes('foundation')) {
          detectedObjects.push('Foundation Wall', 'Concrete');
        }

        if (analysisResult.toLowerCase().includes('electrical')) {
          detectedObjects.push('Electrical Panel', 'Wiring');
        }

        confidence = 0.85; // Default confidence

        // Store AI analysis
        await storage.createAiAnalysis({
          mediaItemId: mediaItem.id,
          analysisText: analysisResult,
          detectedObjects,
          detectedIssues,
          confidence,
        });

      } catch (aiError) {
        console.error('AI analysis failed:', aiError);
        // Continue without AI analysis if it fails
      }

      res.json(mediaItem);
    } catch (error) {
      console.error('Upload error:', error);
      res.status(500).json({ message: 'Failed to upload media' });
    }
  });

  // Get all media items
  app.get('/api/media', async (req, res) => {
    try {
      const mediaItems = await storage.getAllMediaItems();
      res.json(mediaItems);
    } catch (error) {
      console.error('Error fetching media:', error);
      res.status(500).json({ message: 'Failed to fetch media' });
    }
  });

  // Get specific media item with analysis
  app.get('/api/media/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const mediaItem = await storage.getMediaItem(id);
      
      if (!mediaItem) {
        return res.status(404).json({ message: 'Media item not found' });
      }
      
      res.json(mediaItem);
    } catch (error) {
      console.error('Error fetching media item:', error);
      res.status(500).json({ message: 'Failed to fetch media item' });
    }
  });

  // Serve uploaded files
  app.get('/api/media/:id/file', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const mediaItem = await storage.getMediaItem(id);
      
      if (!mediaItem) {
        return res.status(404).json({ message: 'Media item not found' });
      }
      
      const filePath = path.join('uploads', mediaItem.filename);
      
      if (!fs.existsSync(filePath)) {
        return res.status(404).json({ message: 'File not found' });
      }
      
      res.setHeader('Content-Type', mediaItem.mimeType);
      res.sendFile(path.resolve(filePath));
    } catch (error) {
      console.error('Error serving file:', error);
      res.status(500).json({ message: 'Failed to serve file' });
    }
  });

  // Get media statistics
  app.get('/api/stats', async (req, res) => {
    try {
      const stats = await storage.getMediaStats();
      res.json(stats);
    } catch (error) {
      console.error('Error fetching stats:', error);
      res.status(500).json({ message: 'Failed to fetch statistics' });
    }
  });

  // Reports endpoints
  app.post('/api/reports', async (req, res) => {
    try {
      const reportData = insertReportSchema.parse(req.body);
      const report = await storage.createReport(reportData);
      res.json(report);
    } catch (error) {
      console.error('Error creating report:', error);
      res.status(500).json({ message: 'Failed to create report' });
    }
  });

  app.get('/api/reports', async (req, res) => {
    try {
      const reports = await storage.getAllReports();
      res.json(reports);
    } catch (error) {
      console.error('Error fetching reports:', error);
      res.status(500).json({ message: 'Failed to fetch reports' });
    }
  });

  app.get('/api/reports/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const report = await storage.getReport(id);
      
      if (!report) {
        return res.status(404).json({ message: 'Report not found' });
      }
      
      res.json(report);
    } catch (error) {
      console.error('Error fetching report:', error);
      res.status(500).json({ message: 'Failed to fetch report' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
