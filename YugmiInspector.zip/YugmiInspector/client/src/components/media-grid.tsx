import { MediaWithAnalysis } from "@shared/schema";
import { TagChip } from "./tag-chip";
import { Card } from "./ui/card";
import { cn } from "@/lib/utils";

interface MediaGridProps {
  mediaItems: MediaWithAnalysis[];
  onItemClick: (item: MediaWithAnalysis) => void;
  columns?: 2 | 3 | 4;
  className?: string;
}

export function MediaGrid({ mediaItems, onItemClick, columns = 2, className }: MediaGridProps) {
  const formatTimeAgo = (timestamp: Date) => {
    const now = new Date();
    const diff = now.getTime() - new Date(timestamp).getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return 'Just now';
  };

  const getLocationDisplay = (item: MediaWithAnalysis) => {
    if (item.locationName) return item.locationName;
    if (item.latitude && item.longitude) {
      return `${item.latitude.toFixed(4)}°, ${item.longitude.toFixed(4)}°`;
    }
    return 'Unknown location';
  };

  return (
    <div className={cn(
      "grid gap-3",
      {
        'grid-cols-2': columns === 2,
        'grid-cols-3': columns === 3,
        'grid-cols-4': columns === 4,
      },
      className
    )}>
      {mediaItems.map((item) => (
        <Card
          key={item.id}
          className="relative card-elevation rounded-lg overflow-hidden cursor-pointer transition-all hover:shadow-lg"
          onClick={() => onItemClick(item)}
        >
          {/* Media Preview */}
          <div className="relative">
            <img
              src={`/api/media/${item.id}/file`}
              alt={item.originalName}
              className="w-full h-32 object-cover"
              loading="lazy"
            />
            
            {/* AI Analysis Overlay */}
            {item.analysis && (
              <div className="absolute top-2 left-2 right-2">
                <div className="flex flex-wrap gap-1">
                  {item.analysis.detectedObjects?.slice(0, 2).map((object, index) => (
                    <TagChip key={index} size="sm">
                      {object}
                    </TagChip>
                  ))}
                  {item.analysis.detectedIssues?.slice(0, 1).map((issue, index) => (
                    <TagChip key={`issue-${index}`} variant="issue" size="sm">
                      {issue.type}
                    </TagChip>
                  ))}
                </div>
              </div>
            )}
            
            {/* Media Type Indicator */}
            <div className="absolute bottom-2 right-2">
              <div className="bg-black bg-opacity-50 rounded p-1">
                {item.type === 'image' ? (
                  <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" />
                  </svg>
                ) : (
                  <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M2 6a2 2 0 012-2h6l2 2h6a2 2 0 012 2v6a2 2 0 01-2 2H4a2 2 0 01-2-2V6zM5 8a1 1 0 011-1h1a1 1 0 010 2H6a1 1 0 01-1-1zm6 1a1 1 0 100 2h3a1 1 0 100-2H11z" />
                  </svg>
                )}
              </div>
            </div>
          </div>
          
          {/* Metadata */}
          <div className="p-3">
            <div className="text-xs text-muted-foreground">
              {formatTimeAgo(item.createdAt)}
            </div>
            <div className="text-xs text-muted-foreground mt-1 flex items-center">
              <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
              </svg>
              <span className="truncate">{getLocationDisplay(item)}</span>
            </div>
            {item.analysis && item.analysis.confidence && (
              <div className="text-xs text-muted-foreground mt-1">
                AI: {Math.round(item.analysis.confidence * 100)}% confidence
              </div>
            )}
          </div>
        </Card>
      ))}
    </div>
  );
}
