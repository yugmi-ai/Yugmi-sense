import { cn } from "@/lib/utils";

interface TagChipProps {
  children: React.ReactNode;
  variant?: 'default' | 'issue' | 'warning' | 'success';
  size?: 'sm' | 'md';
  className?: string;
}

export function TagChip({ children, variant = 'default', size = 'sm', className }: TagChipProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full font-medium",
        {
          'px-2 py-1 text-xs': size === 'sm',
          'px-3 py-1.5 text-sm': size === 'md',
        },
        {
          'tag-chip': variant === 'default',
          'issue-chip': variant === 'issue',
          'bg-orange-100 text-orange-800': variant === 'warning',
          'bg-green-100 text-green-800': variant === 'success',
        },
        className
      )}
    >
      {children}
    </span>
  );
}
