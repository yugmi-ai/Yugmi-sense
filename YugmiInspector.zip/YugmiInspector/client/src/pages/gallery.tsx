import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { MediaGrid } from "@/components/media-grid";
import { MediaWithAnalysis } from "@shared/schema";

export default function Gallery() {
  const [, setLocation] = useLocation();
  const [activeFilter, setActiveFilter] = useState('all');

  const { data: mediaItems = [], isLoading } = useQuery({
    queryKey: ["/api/media"],
  });

  const filteredMedia = mediaItems.filter((item: MediaWithAnalysis) => {
    switch (activeFilter) {
      case 'photos':
        return item.type === 'image';
      case 'videos':
        return item.type === 'video';
      case 'issues':
        return item.analysis?.detectedIssues && item.analysis.detectedIssues.length > 0;
      case 'today':
        const today = new Date();
        const itemDate = new Date(item.createdAt);
        return itemDate.toDateString() === today.toDateString();
      default:
        return true;
    }
  });

  const filters = [
    { id: 'all', label: 'All Media' },
    { id: 'photos', label: 'Photos' },
    { id: 'videos', label: 'Videos' },
    { id: 'issues', label: 'Issues' },
    { id: 'today', label: 'Today' },
  ];

  const handleMediaClick = (item: MediaWithAnalysis) => {
    setLocation(`/media/${item.id}`);
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-primary text-primary-foreground px-4 py-4 flex items-center">
        <Button
          variant="ghost"
          size="icon"
          className="mr-4 hover:bg-primary-dark"
          onClick={() => setLocation('/')}
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </Button>
        <h1 className="text-lg font-medium flex-1">Media Gallery</h1>
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="icon" className="hover:bg-primary-dark">
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
              <path d="M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2H5zM11 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V5zM11 13a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
            </svg>
          </Button>
          <Button variant="ghost" size="icon" className="hover:bg-primary-dark">
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M3 3a1 1 0 011-1h12a1 1 0 011 1v3a1 1 0 01-.293.707L12 11.414V15a1 1 0 01-.293.707l-2 2A1 1 0 018 17v-5.586L3.293 6.707A1 1 0 013 6V3z" clipRule="evenodd" />
            </svg>
          </Button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="bg-surface border-b border-gray-200">
        <div className="flex overflow-x-auto px-4 py-3 space-x-4">
          {filters.map((filter) => (
            <button
              key={filter.id}
              onClick={() => setActiveFilter(filter.id)}
              className={`whitespace-nowrap px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                activeFilter === filter.id
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {filter.label}
            </button>
          ))}
        </div>
      </div>

      {/* Media Grid */}
      <div className="p-4">
        {isLoading ? (
          <div className="grid grid-cols-2 gap-3">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="bg-gray-200 rounded-lg h-32 mb-3"></div>
                <div className="h-4 bg-gray-200 rounded mb-2"></div>
                <div className="h-3 bg-gray-200 rounded w-3/4"></div>
              </div>
            ))}
          </div>
        ) : filteredMedia.length > 0 ? (
          <MediaGrid
            mediaItems={filteredMedia}
            onItemClick={handleMediaClick}
            columns={2}
          />
        ) : (
          <div className="text-center py-12">
            <svg className="w-16 h-16 mx-auto text-gray-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No media found</h3>
            <p className="text-gray-500 mb-6">
              {activeFilter === 'all' 
                ? "Start by capturing your first photo or video"
                : `No ${activeFilter} found. Try a different filter.`
              }
            </p>
            <Button onClick={() => setLocation('/camera')}>
              <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M4 5a2 2 0 00-2 2v8a2 2 0 002 2h12a2 2 0 002-2V7a2 2 0 00-2-2h-1.586a1 1 0 01-.707-.293l-1.121-1.121A2 2 0 0011.172 3H8.828a2 2 0 00-1.414.586L6.293 4.707A1 1 0 015.586 5H4zm6 9a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" />
              </svg>
              Capture Media
            </Button>
          </div>
        )}
      </div>

      {/* Floating Action Button */}
      <Button
        className="fab fixed bottom-20 right-6 w-14 h-14 rounded-full shadow-lg"
        onClick={() => setLocation('/camera')}
      >
        <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
          <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
        </svg>
      </Button>
    </div>
  );
}
