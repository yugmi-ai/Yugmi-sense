import { useQuery } from "@tanstack/react-query";
import { useLocation, useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { TagChip } from "@/components/tag-chip";
import { Progress } from "@/components/ui/progress";

export default function MediaDetail() {
  const [, params] = useRoute("/media/:id");
  const [, setLocation] = useLocation();
  
  const mediaId = params?.id;

  const { data: media, isLoading, error } = useQuery({
    queryKey: ["/api/media", mediaId],
    enabled: !!mediaId,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="bg-black text-white px-4 py-4 flex items-center">
          <Button
            variant="ghost"
            size="icon"
            className="mr-4"
            onClick={() => setLocation('/gallery')}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </Button>
          <div>
            <div className="text-sm font-medium">Loading...</div>
          </div>
        </div>
        
        <div className="p-4">
          <div className="animate-pulse">
            <div className="bg-gray-300 h-64 rounded-lg mb-4"></div>
            <div className="h-4 bg-gray-300 rounded mb-2"></div>
            <div className="h-4 bg-gray-300 rounded w-3/4 mb-4"></div>
            <div className="space-y-2">
              <div className="h-3 bg-gray-300 rounded"></div>
              <div className="h-3 bg-gray-300 rounded"></div>
              <div className="h-3 bg-gray-300 rounded w-1/2"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !media) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <svg className="w-16 h-16 mx-auto text-gray-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.732-.833-2.5 0L4.268 18.5c-.77.833.192 2.5 1.732 2.5z" />
          </svg>
          <h2 className="text-xl font-semibold mb-2">Media Not Found</h2>
          <p className="text-gray-600 mb-4">The requested media item could not be found.</p>
          <Button onClick={() => setLocation('/gallery')}>
            Back to Gallery
          </Button>
        </div>
      </div>
    );
  }

  const formatDate = (timestamp: string) => {
    return new Date(timestamp).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatLocation = () => {
    if (media.locationName) return media.locationName;
    if (media.latitude && media.longitude) {
      return `${media.latitude.toFixed(4)}°, ${media.longitude.toFixed(4)}°`;
    }
    return 'Unknown location';
  };

  const formatFileSize = (bytes: number) => {
    const units = ['B', 'KB', 'MB', 'GB'];
    let size = bytes;
    let unitIndex = 0;
    
    while (size >= 1024 && unitIndex < units.length - 1) {
      size /= 1024;
      unitIndex++;
    }
    
    return `${size.toFixed(1)} ${units[unitIndex]}`;
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-black text-white px-4 py-4 flex items-center">
        <Button
          variant="ghost"
          size="icon"
          className="mr-4"
          onClick={() => setLocation('/gallery')}
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </Button>
        <div className="flex-1">
          <div className="text-sm font-medium">{media.originalName}</div>
          <div className="text-xs text-gray-300">
            {formatDate(media.createdAt.toString())}
          </div>
        </div>
        <Button variant="ghost" size="icon">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z" />
          </svg>
        </Button>
      </div>

      {/* Media Display */}
      <div className="bg-black">
        {media.type === 'image' ? (
          <img
            src={`/api/media/${media.id}/file`}
            alt={media.originalName}
            className="w-full h-64 object-contain"
          />
        ) : (
          <video
            src={`/api/media/${media.id}/file`}
            className="w-full h-64 object-contain"
            controls
          />
        )}
      </div>

      {/* AI Analysis Section */}
      {media.analysis && (
        <Card className="m-4">
          <CardContent className="p-4">
            <h3 className="text-lg font-medium text-text-primary mb-3">AI Analysis Results</h3>
            
            {/* Detected Objects */}
            {media.analysis.detectedObjects && media.analysis.detectedObjects.length > 0 && (
              <div className="mb-4">
                <h4 className="text-sm font-medium text-text-primary mb-2">Detected Objects</h4>
                <div className="flex flex-wrap gap-2">
                  {media.analysis.detectedObjects.map((object, index) => (
                    <TagChip key={index} size="sm">
                      {object}
                    </TagChip>
                  ))}
                </div>
              </div>
            )}

            {/* Issues Detected */}
            {media.analysis.detectedIssues && media.analysis.detectedIssues.length > 0 && (
              <div className="mb-4">
                <h4 className="text-sm font-medium text-text-primary mb-2">Issues Detected</h4>
                <div className="space-y-2">
                  {media.analysis.detectedIssues.map((issue, index) => (
                    <div key={index} className="bg-red-50 border border-red-200 rounded-lg p-3">
                      <div className="flex items-center space-x-2">
                        <svg className="w-4 h-4 text-red-600" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                        </svg>
                        <span className="text-sm font-medium text-red-800">
                          {issue.type.replace('_', ' ').toUpperCase()}
                        </span>
                        <TagChip 
                          variant={issue.severity === 'critical' ? 'issue' : 'warning'} 
                          size="sm"
                          className="ml-auto"
                        >
                          {issue.severity}
                        </TagChip>
                      </div>
                      <p className="text-xs text-red-700 mt-1">
                        {issue.description}
                      </p>
                      <div className="text-xs text-red-600 mt-1">
                        Confidence: {Math.round(issue.confidence * 100)}%
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Confidence Score */}
            <div className="mb-4">
              <h4 className="text-sm font-medium text-text-primary mb-2">Analysis Confidence</h4>
              <Progress value={media.analysis.confidence * 100} className="h-2" />
              <div className="text-xs text-muted-foreground mt-1">
                {Math.round(media.analysis.confidence * 100)}% confidence
              </div>
            </div>

            {/* Analysis Text */}
            {media.analysis.analysisText && (
              <div>
                <h4 className="text-sm font-medium text-text-primary mb-2">Detailed Analysis</h4>
                <p className="text-sm text-muted-foreground">
                  {media.analysis.analysisText}
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Location & Metadata */}
      <Card className="m-4">
        <CardContent className="p-4">
          <h3 className="text-lg font-medium text-text-primary mb-3">Details</h3>
          
          <div className="space-y-3">
            <div className="flex items-center space-x-3">
              <svg className="w-5 h-5 text-muted-foreground" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
              </svg>
              <div>
                <div className="text-sm font-medium text-text-primary">
                  {formatLocation()}
                </div>
                {media.locationAddress && (
                  <div className="text-xs text-muted-foreground">
                    {media.locationAddress}
                  </div>
                )}
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <svg className="w-5 h-5 text-muted-foreground" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
              </svg>
              <div>
                <div className="text-sm font-medium text-text-primary">
                  {formatDate(media.createdAt.toString())}
                </div>
                <div className="text-xs text-muted-foreground">
                  Captured during field inspection
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <svg className="w-5 h-5 text-muted-foreground" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M4 4a2 2 0 00-2 2v4a2 2 0 002 2V6h10a2 2 0 00-2-2H4zm2 6a2 2 0 012-2h8a2 2 0 012 2v4a2 2 0 01-2 2H8a2 2 0 01-2-2v-4zm6 4a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
              </svg>
              <div>
                <div className="text-sm font-medium text-text-primary">File Size</div>
                <div className="text-xs text-muted-foreground">
                  {formatFileSize(media.size)} • {media.type.toUpperCase()}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <Card className="m-4">
        <CardContent className="p-4">
          <div className="grid grid-cols-2 gap-4">
            <Button className="flex items-center justify-center space-x-2">
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clipRule="evenodd" />
              </svg>
              <span className="text-sm font-medium">Add to Report</span>
            </Button>
            <Button variant="outline" className="flex items-center justify-center space-x-2">
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M17.707 9.293a1 1 0 010 1.414l-7 7a1 1 0 01-1.414 0l-7-7A.997.997 0 012 10V5a3 3 0 013-3h5c.256 0 .512.098.707.293l7 7zM5 6a1 1 0 100 2 1 1 0 000-2z" clipRule="evenodd" />
              </svg>
              <span className="text-sm font-medium">Edit Tags</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
