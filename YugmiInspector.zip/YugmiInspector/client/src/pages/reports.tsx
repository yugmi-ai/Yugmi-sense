import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { insertReportSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export default function Reports() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [newReport, setNewReport] = useState({
    title: '',
    type: 'Daily Inspection Report',
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date().toISOString().split('T')[0],
    includeImages: true,
    includeIssues: true,
    includeLocation: false,
  });

  const { data: reports = [], isLoading: reportsLoading } = useQuery({
    queryKey: ["/api/reports"],
  });

  const createReportMutation = useMutation({
    mutationFn: async (reportData: any) => {
      return await apiRequest('POST', '/api/reports', reportData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reports"] });
      toast({
        title: "Success",
        description: "Report created successfully",
      });
      // Reset form
      setNewReport({
        title: '',
        type: 'Daily Inspection Report',
        startDate: new Date().toISOString().split('T')[0],
        endDate: new Date().toISOString().split('T')[0],
        includeImages: true,
        includeIssues: true,
        includeLocation: false,
      });
    },
    onError: (error) => {
      console.error('Report creation error:', error);
      toast({
        title: "Error",
        description: "Failed to create report. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleGenerateReport = () => {
    if (!newReport.title.trim()) {
      toast({
        title: "Validation Error",
        description: "Please enter a report title",
        variant: "destructive",
      });
      return;
    }

    const reportData = {
      title: newReport.title,
      type: newReport.type,
      status: 'draft',
      startDate: new Date(newReport.startDate),
      endDate: new Date(newReport.endDate),
      includeImages: newReport.includeImages,
      includeIssues: newReport.includeIssues,
      includeLocation: newReport.includeLocation,
      content: {
        summary: `Generated ${newReport.type} for period ${newReport.startDate} to ${newReport.endDate}`,
        mediaItems: [],
        issues: [],
      }
    };

    createReportMutation.mutate(reportData);
  };

  const formatDate = (timestamp: string) => {
    return new Date(timestamp).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'draft':
        return 'bg-orange-100 text-orange-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // Calculate report stats
  const reportStats = {
    draftCount: reports.filter((r: any) => r.status === 'draft').length,
    completedCount: reports.filter((r: any) => r.status === 'completed').length,
    pendingCount: reports.filter((r: any) => r.status === 'pending').length,
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-primary text-primary-foreground px-4 py-4 flex items-center">
        <Button
          variant="ghost"
          size="icon"
          className="mr-4 hover:bg-primary-dark"
          onClick={() => setLocation('/')}
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </Button>
        <h1 className="text-lg font-medium flex-1">Inspection Reports</h1>
        <Button 
          variant="ghost" 
          size="icon" 
          className="hover:bg-primary-dark"
          onClick={handleGenerateReport}
          disabled={createReportMutation.isPending}
        >
          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
          </svg>
        </Button>
      </div>

      {/* Quick Stats */}
      <div className="bg-surface px-4 py-6 border-b border-gray-200">
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <div className="text-2xl font-medium text-text-primary">
              {reportStats.draftCount}
            </div>
            <div className="text-xs text-text-secondary">Drafts</div>
          </div>
          <div>
            <div className="text-2xl font-medium text-secondary">
              {reportStats.completedCount}
            </div>
            <div className="text-xs text-text-secondary">Completed</div>
          </div>
          <div>
            <div className="text-2xl font-medium text-warning">
              {reportStats.pendingCount}
            </div>
            <div className="text-xs text-text-secondary">Pending</div>
          </div>
        </div>
      </div>

      {/* Generate New Report */}
      <Card className="m-4">
        <CardContent className="p-4">
          <h2 className="text-lg font-medium text-text-primary mb-4">Generate New Report</h2>
          <div className="space-y-4">
            <div>
              <Label htmlFor="title" className="block text-sm font-medium text-text-primary mb-2">
                Report Title
              </Label>
              <Input
                id="title"
                value={newReport.title}
                onChange={(e) => setNewReport(prev => ({ ...prev, title: e.target.value }))}
                placeholder="Enter report title"
                className="w-full"
              />
            </div>
            
            <div>
              <Label htmlFor="type" className="block text-sm font-medium text-text-primary mb-2">
                Report Type
              </Label>
              <Select 
                value={newReport.type} 
                onValueChange={(value) => setNewReport(prev => ({ ...prev, type: value }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Daily Inspection Report">Daily Inspection Report</SelectItem>
                  <SelectItem value="Issue Summary Report">Issue Summary Report</SelectItem>
                  <SelectItem value="Progress Report">Progress Report</SelectItem>
                  <SelectItem value="Compliance Report">Compliance Report</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label className="block text-sm font-medium text-text-primary mb-2">
                Date Range
              </Label>
              <div className="grid grid-cols-2 gap-3">
                <Input
                  type="date"
                  value={newReport.startDate}
                  onChange={(e) => setNewReport(prev => ({ ...prev, startDate: e.target.value }))}
                />
                <Input
                  type="date"
                  value={newReport.endDate}
                  onChange={(e) => setNewReport(prev => ({ ...prev, endDate: e.target.value }))}
                />
              </div>
            </div>
            
            <div>
              <Label className="block text-sm font-medium text-text-primary mb-2">
                Include
              </Label>
              <div className="space-y-2">
                <div className="flex items-center space-x-3">
                  <Checkbox
                    id="includeImages"
                    checked={newReport.includeImages}
                    onCheckedChange={(checked) => 
                      setNewReport(prev => ({ ...prev, includeImages: !!checked }))
                    }
                  />
                  <Label htmlFor="includeImages" className="text-sm text-text-primary">
                    Images with AI analysis
                  </Label>
                </div>
                <div className="flex items-center space-x-3">
                  <Checkbox
                    id="includeIssues"
                    checked={newReport.includeIssues}
                    onCheckedChange={(checked) => 
                      setNewReport(prev => ({ ...prev, includeIssues: !!checked }))
                    }
                  />
                  <Label htmlFor="includeIssues" className="text-sm text-text-primary">
                    Detected issues
                  </Label>
                </div>
                <div className="flex items-center space-x-3">
                  <Checkbox
                    id="includeLocation"
                    checked={newReport.includeLocation}
                    onCheckedChange={(checked) => 
                      setNewReport(prev => ({ ...prev, includeLocation: !!checked }))
                    }
                  />
                  <Label htmlFor="includeLocation" className="text-sm text-text-primary">
                    Location data
                  </Label>
                </div>
              </div>
            </div>
            
            <Button 
              className="w-full" 
              onClick={handleGenerateReport}
              disabled={createReportMutation.isPending}
            >
              {createReportMutation.isPending ? (
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Generating...</span>
                </div>
              ) : (
                'Generate Report'
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Recent Reports */}
      <div className="px-4 pb-6">
        <h2 className="text-lg font-medium text-text-primary mb-4">Recent Reports</h2>
        {reportsLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-4">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2 mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/4"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : reports.length > 0 ? (
          <div className="space-y-3">
            {reports.map((report: any) => (
              <Card key={report.id} className="card-elevation">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="text-sm font-medium text-text-primary">
                        {report.title}
                      </div>
                      <div className="text-xs text-text-secondary mt-1">
                        {formatDate(report.createdAt)}
                      </div>
                      <div className="flex items-center mt-2 space-x-4 text-xs text-text-secondary">
                        <span className="flex items-center space-x-1">
                          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" />
                          </svg>
                          <span>{report.content?.mediaItems?.length || 0} images</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                          </svg>
                          <span>{report.content?.issues?.length || 0} issues</span>
                        </span>
                      </div>
                    </div>
                    <div className="flex flex-col items-end space-y-2">
                      <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(report.status)}`}>
                        {report.status}
                      </span>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        {report.status === 'completed' ? (
                          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
                          </svg>
                        ) : (
                          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" />
                          </svg>
                        )}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="p-6 text-center">
              <svg className="w-12 h-12 mx-auto text-gray-400 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              <p className="text-text-secondary">No reports generated yet</p>
              <p className="text-sm text-text-secondary mt-1">Create your first inspection report</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
