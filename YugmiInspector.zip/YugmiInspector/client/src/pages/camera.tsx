import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useCamera } from "@/hooks/use-camera";
import { useGeolocation } from "@/hooks/use-geolocation";
import { uploadMedia } from "@/lib/media-utils";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";

export default function Camera() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [mode, setMode] = useState<'photo' | 'video'>('photo');
  const [isUploading, setIsUploading] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  
  const {
    videoRef,
    isActive,
    isRecording,
    error: cameraError,
    startCamera,
    stopCamera,
    capturePhoto,
    startRecording,
    stopRecording,
    switchCamera,
    toggleFlash
  } = useCamera();

  const {
    latitude,
    longitude,
    address,
    getCurrentLocation
  } = useGeolocation();

  // Recording timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRecording) {
      interval = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
    } else {
      setRecordingTime(0);
    }
    return () => clearInterval(interval);
  }, [isRecording]);

  // Initialize camera and location on mount
  useEffect(() => {
    startCamera();
    getCurrentLocation();
    
    return () => {
      stopCamera();
    };
  }, [startCamera, stopCamera, getCurrentLocation]);

  const uploadMutation = useMutation({
    mutationFn: uploadMedia,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/media"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Success",
        description: `${mode === 'photo' ? 'Photo' : 'Video'} uploaded successfully`,
      });
      setLocation('/gallery');
    },
    onError: (error) => {
      console.error('Upload error:', error);
      toast({
        title: "Upload Failed",
        description: "Failed to upload media. Please try again.",
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsUploading(false);
    }
  });

  const handleCapture = async () => {
    try {
      if (mode === 'photo') {
        const photoBlob = await capturePhoto();
        if (photoBlob) {
          setIsUploading(true);
          uploadMutation.mutate({
            file: photoBlob,
            latitude,
            longitude,
            locationAddress: address,
          });
        }
      } else {
        if (isRecording) {
          const videoBlob = await stopRecording();
          if (videoBlob) {
            setIsUploading(true);
            uploadMutation.mutate({
              file: videoBlob,
              latitude,
              longitude,
              locationAddress: address,
            });
          }
        } else {
          await startRecording();
        }
      }
    } catch (error) {
      console.error('Capture error:', error);
      toast({
        title: "Capture Failed",
        description: "Failed to capture media. Please try again.",
        variant: "destructive",
      });
    }
  };

  const formatRecordingTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  if (cameraError) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-white text-center p-6">
          <svg className="w-16 h-16 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.732-.833-2.5 0L4.268 18.5c-.77.833.192 2.5 1.732 2.5z" />
          </svg>
          <h2 className="text-xl font-semibold mb-2">Camera Error</h2>
          <p className="text-gray-300 mb-4">{cameraError}</p>
          <Button onClick={() => setLocation('/')} variant="outline">
            Go Back
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative min-h-screen bg-black">
      {/* Camera Preview */}
      <div className="absolute inset-0">
        {isActive ? (
          <div className="camera-viewfinder h-full">
            <video
              ref={videoRef}
              className="w-full h-full object-cover"
              playsInline
              muted
            />
            <div className="grid-overlay"></div>
          </div>
        ) : (
          <div className="h-full flex items-center justify-center text-white">
            <div className="text-center">
              <svg className="w-16 h-16 mx-auto mb-4" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M4 5a2 2 0 00-2 2v8a2 2 0 002 2h12a2 2 0 002-2V7a2 2 0 00-2-2h-1.586a1 1 0 01-.707-.293l-1.121-1.121A2 2 0 0011.172 3H8.828a2 2 0 00-1.414.586L6.293 4.707A1 1 0 015.586 5H4zm6 9a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" />
              </svg>
              <p>Starting camera...</p>
            </div>
          </div>
        )}
      </div>

      {/* Camera Overlay UI */}
      <div className="capture-overlay absolute inset-0 pointer-events-none">
        {/* Top Controls */}
        <div className="absolute top-0 left-0 right-0 p-4 flex justify-between items-center pointer-events-auto">
          <Button
            variant="ghost"
            size="icon"
            className="w-10 h-10 rounded-full bg-black bg-opacity-50 hover:bg-opacity-70"
            onClick={() => setLocation('/')}
          >
            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </Button>
          
          <div className="flex space-x-2">
            <Button
              variant="ghost"
              size="icon"
              className="w-10 h-10 rounded-full bg-black bg-opacity-50 hover:bg-opacity-70"
              onClick={toggleFlash}
            >
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              className="w-10 h-10 rounded-full bg-black bg-opacity-50 hover:bg-opacity-70"
              onClick={switchCamera}
            >
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
            </Button>
          </div>
        </div>

        {/* Recording Indicator */}
        {isRecording && (
          <div className="absolute top-16 left-1/2 transform -translate-x-1/2 bg-red-600 rounded-full px-3 py-1 flex items-center space-x-2 pointer-events-none">
            <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
            <span className="text-white text-sm font-medium">
              {formatRecordingTime(recordingTime)}
            </span>
          </div>
        )}

        {/* Bottom Controls */}
        <div className="absolute bottom-0 left-0 right-0 p-6 pointer-events-auto">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              className="w-12 h-12 rounded-lg border-2 border-white p-0 overflow-hidden"
              onClick={() => setLocation('/gallery')}
            >
              <div className="w-full h-full bg-gray-600 flex items-center justify-center">
                <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" />
                </svg>
              </div>
            </Button>
            
            {/* Capture Button */}
            <Button
              variant="ghost"
              className={`w-20 h-20 rounded-full border-4 border-white p-0 ${
                mode === 'video' && isRecording ? 'bg-red-600' : 'bg-white'
              }`}
              onClick={handleCapture}
              disabled={isUploading}
            >
              {isUploading ? (
                <div className="w-8 h-8 border-2 border-gray-400 border-t-transparent rounded-full animate-spin"></div>
              ) : mode === 'video' && isRecording ? (
                <div className="w-6 h-6 bg-white rounded-sm"></div>
              ) : (
                <div className={`w-16 h-16 rounded-full ${mode === 'video' ? 'bg-red-600' : 'bg-white'}`}></div>
              )}
            </Button>
            
            {/* Mode Selector */}
            <div className="text-white text-center">
              <div className="text-sm font-medium">
                {mode.toUpperCase()}
              </div>
              <div className="flex space-x-4 mt-2 text-xs">
                <button
                  onClick={() => setMode('photo')}
                  className={mode === 'photo' ? 'text-yellow-400' : 'text-gray-400'}
                >
                  PHOTO
                </button>
                <button
                  onClick={() => setMode('video')}
                  className={mode === 'video' ? 'text-yellow-400' : 'text-gray-400'}
                >
                  VIDEO
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Location Info */}
      {(latitude && longitude) && (
        <div className="absolute top-16 left-4 right-4 bg-black bg-opacity-50 rounded-lg p-3 text-white text-sm pointer-events-none">
          <div className="flex items-center space-x-2">
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
            </svg>
            <span>{latitude.toFixed(4)}°, {longitude.toFixed(4)}°</span>
          </div>
          {address && (
            <div className="mt-1 text-xs text-gray-300 truncate">
              {address}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
