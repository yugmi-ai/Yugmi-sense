import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TagChip } from "@/components/tag-chip";
import { useGeolocation } from "@/hooks/use-geolocation";
import { MediaWithAnalysis } from "@shared/schema";
import { useEffect } from "react";

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const { latitude, longitude, address, getCurrentLocation } = useGeolocation();

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/stats"],
  });

  const { data: recentMedia, isLoading: mediaLoading } = useQuery({
    queryKey: ["/api/media"],
  });

  useEffect(() => {
    getCurrentLocation();
  }, [getCurrentLocation]);

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const diff = now.getTime() - new Date(timestamp).getTime();
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (days > 0) return `${days} days ago`;
    if (hours > 0) return `${hours} hours ago`;
    return 'Recently';
  };

  const getIssueType = (media: MediaWithAnalysis) => {
    if (media.analysis?.detectedIssues && media.analysis.detectedIssues.length > 0) {
      const issue = media.analysis.detectedIssues[0];
      return {
        type: issue.type.replace('_', ' '),
        severity: issue.severity
      };
    }
    return null;
  };

  const recentActivity = recentMedia?.slice(0, 3) || [];

  return (
    <div className="min-h-screen bg-background-app pb-20">
      {/* Status Bar */}
      <div className="bg-primary text-primary-foreground px-4 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
          </svg>
          <span className="text-sm truncate">
            {address || 'Getting location...'}
          </span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
            <path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V4zM3 10a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H4a1 1 0 01-1-1v-6zM14 9a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z" />
          </svg>
        </div>
      </div>

      {/* Header */}
      <div className="bg-surface px-4 py-6 border-b border-gray-200">
        <h1 className="text-2xl font-medium text-text-primary">Yugmi Sense</h1>
        <p className="text-text-secondary mt-1">Field Inspection Dashboard</p>
        
        {/* Stats Grid */}
        <div className="mt-4 grid grid-cols-3 gap-4 text-center">
          <div className="bg-blue-50 rounded-lg p-3">
            <div className="text-xl font-medium text-primary">
              {statsLoading ? '...' : stats?.imagesCount || 0}
            </div>
            <div className="text-xs text-text-secondary">Images</div>
          </div>
          <div className="bg-green-50 rounded-lg p-3">
            <div className="text-xl font-medium text-secondary">
              {statsLoading ? '...' : stats?.videosCount || 0}
            </div>
            <div className="text-xs text-text-secondary">Videos</div>
          </div>
          <div className="bg-orange-50 rounded-lg p-3">
            <div className="text-xl font-medium text-warning">
              {statsLoading ? '...' : stats?.issuesCount || 0}
            </div>
            <div className="text-xs text-text-secondary">Issues</div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="px-4 py-6">
        <h2 className="text-lg font-medium text-text-primary mb-4">Quick Actions</h2>
        <div className="grid grid-cols-2 gap-4">
          <Button
            variant="outline"
            className="card-elevation h-auto p-6 flex flex-col items-center space-y-2"
            onClick={() => setLocation('/camera')}
          >
            <svg className="w-8 h-8 text-primary" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M4 5a2 2 0 00-2 2v8a2 2 0 002 2h12a2 2 0 002-2V7a2 2 0 00-2-2h-1.586a1 1 0 01-.707-.293l-1.121-1.121A2 2 0 0011.172 3H8.828a2 2 0 00-1.414.586L6.293 4.707A1 1 0 015.586 5H4zm6 9a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" />
            </svg>
            <div className="text-sm font-medium">Capture Photo</div>
          </Button>

          <Button
            variant="outline"
            className="card-elevation h-auto p-6 flex flex-col items-center space-y-2"
            onClick={() => setLocation('/camera?mode=video')}
          >
            <svg className="w-8 h-8 text-primary" fill="currentColor" viewBox="0 0 20 20">
              <path d="M2 6a2 2 0 012-2h6l2 2h6a2 2 0 012 2v6a2 2 0 01-2 2H4a2 2 0 01-2-2V6zM5 8a1 1 0 011-1h1a1 1 0 010 2H6a1 1 0 01-1-1zm6 1a1 1 0 100 2h3a1 1 0 100-2H11z" />
            </svg>
            <div className="text-sm font-medium">Record Video</div>
          </Button>

          <Button
            variant="outline"
            className="card-elevation h-auto p-6 flex flex-col items-center space-y-2"
            onClick={() => setLocation('/gallery')}
          >
            <svg className="w-8 h-8 text-primary" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" />
            </svg>
            <div className="text-sm font-medium">View Gallery</div>
          </Button>

          <Button
            variant="outline"
            className="card-elevation h-auto p-6 flex flex-col items-center space-y-2"
            onClick={() => setLocation('/reports')}
          >
            <svg className="w-8 h-8 text-primary" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clipRule="evenodd" />
            </svg>
            <div className="text-sm font-medium">Generate Report</div>
          </Button>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="px-4 pb-6">
        <h2 className="text-lg font-medium text-text-primary mb-4">Recent Activity</h2>
        {mediaLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-4 flex items-center space-x-3">
                  <div className="w-12 h-12 bg-gray-200 rounded-lg"></div>
                  <div className="flex-1">
                    <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : recentActivity.length > 0 ? (
          <div className="space-y-3">
            {recentActivity.map((media) => {
              const issue = getIssueType(media);
              
              return (
                <Card key={media.id} className="card-elevation cursor-pointer" onClick={() => setLocation(`/media/${media.id}`)}>
                  <CardContent className="p-4 flex items-center space-x-3">
                    <img
                      src={`/api/media/${media.id}/file`}
                      alt={media.originalName}
                      className="w-12 h-12 rounded-lg object-cover"
                    />
                    <div className="flex-1">
                      <div className="text-sm font-medium text-text-primary">
                        {issue ? `${issue.type} detected` : 'Media captured'}
                      </div>
                      <div className="text-xs text-text-secondary">
                        {formatTimeAgo(media.createdAt.toString())}
                      </div>
                      <div className="flex mt-1 space-x-1">
                        {issue && (
                          <TagChip 
                            variant={issue.severity === 'critical' ? 'issue' : 'warning'} 
                            size="sm"
                          >
                            {issue.severity}
                          </TagChip>
                        )}
                        {media.locationName && (
                          <TagChip size="sm">
                            {media.locationName}
                          </TagChip>
                        )}
                      </div>
                    </div>
                    <svg className="w-5 h-5 text-text-secondary" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
                    </svg>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <Card>
            <CardContent className="p-6 text-center">
              <svg className="w-12 h-12 mx-auto text-gray-400 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 9h6v6h-6z" />
              </svg>
              <p className="text-text-secondary">No recent activity</p>
              <p className="text-sm text-text-secondary mt-1">Start by capturing your first photo or video</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
