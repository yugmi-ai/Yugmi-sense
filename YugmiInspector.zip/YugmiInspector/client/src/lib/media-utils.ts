import { apiRequest } from './queryClient';

export interface UploadProgress {
  loaded: number;
  total: number;
  percentage: number;
}

export interface MediaUploadData {
  file: File | Blob;
  latitude?: number;
  longitude?: number;
  locationName?: string;
  locationAddress?: string;
}

export async function uploadMedia(
  data: MediaUploadData,
  onProgress?: (progress: UploadProgress) => void
): Promise<any> {
  const formData = new FormData();
  
  // Create a file name if it's a blob
  const file = data.file instanceof File 
    ? data.file 
    : new File([data.file], `capture_${Date.now()}.${getFileExtension(data.file)}`, {
        type: data.file.type
      });
  
  formData.append('media', file);
  
  if (data.latitude !== undefined) {
    formData.append('latitude', data.latitude.toString());
  }
  
  if (data.longitude !== undefined) {
    formData.append('longitude', data.longitude.toString());
  }
  
  if (data.locationName) {
    formData.append('locationName', data.locationName);
  }
  
  if (data.locationAddress) {
    formData.append('locationAddress', data.locationAddress);
  }

  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    
    xhr.upload.addEventListener('progress', (event) => {
      if (event.lengthComputable && onProgress) {
        const progress: UploadProgress = {
          loaded: event.loaded,
          total: event.total,
          percentage: Math.round((event.loaded / event.total) * 100)
        };
        onProgress(progress);
      }
    });
    
    xhr.addEventListener('load', () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          const response = JSON.parse(xhr.responseText);
          resolve(response);
        } catch (error) {
          reject(new Error('Invalid response format'));
        }
      } else {
        reject(new Error(`Upload failed with status ${xhr.status}`));
      }
    });
    
    xhr.addEventListener('error', () => {
      reject(new Error('Network error during upload'));
    });
    
    xhr.open('POST', '/api/media/upload');
    xhr.send(formData);
  });
}

export function getFileExtension(file: Blob): string {
  const mimeType = file.type;
  
  const extensions: Record<string, string> = {
    'image/jpeg': 'jpg',
    'image/jpg': 'jpg',
    'image/png': 'png',
    'image/gif': 'gif',
    'video/mp4': 'mp4',
    'video/webm': 'webm',
    'video/mov': 'mov',
    'video/avi': 'avi',
  };
  
  return extensions[mimeType] || 'unknown';
}

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

export function formatDuration(seconds: number): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainingSeconds = Math.floor(seconds % 60);
  
  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  }
  
  return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
}

export function createImageThumbnail(file: File, maxWidth: number = 150, maxHeight: number = 150): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    
    if (!ctx) {
      reject(new Error('Could not get canvas context'));
      return;
    }
    
    img.onload = () => {
      // Calculate new dimensions
      let { width, height } = img;
      
      if (width > height) {
        if (width > maxWidth) {
          height = (height * maxWidth) / width;
          width = maxWidth;
        }
      } else {
        if (height > maxHeight) {
          width = (width * maxHeight) / height;
          height = maxHeight;
        }
      }
      
      canvas.width = width;
      canvas.height = height;
      
      ctx.drawImage(img, 0, 0, width, height);
      resolve(canvas.toDataURL('image/jpeg', 0.7));
    };
    
    img.onerror = () => {
      reject(new Error('Failed to load image'));
    };
    
    img.src = URL.createObjectURL(file);
  });
}

export function blobToDataURL(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

// Store media in local storage for offline capability
export interface StoredMedia {
  id: string;
  blob: string; // base64 data URL
  metadata: {
    filename: string;
    type: string;
    size: number;
    timestamp: number;
    latitude?: number;
    longitude?: number;
    locationName?: string;
    locationAddress?: string;
  };
  synced: boolean;
}

export class OfflineMediaStorage {
  private static readonly STORAGE_KEY = 'yugmi_offline_media';
  
  static async store(media: Omit<StoredMedia, 'id'>): Promise<string> {
    const id = `offline_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const storedMedia: StoredMedia = { ...media, id };
    
    const existing = this.getAll();
    existing.push(storedMedia);
    
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(existing));
    return id;
  }
  
  static getAll(): StoredMedia[] {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Failed to load offline media:', error);
      return [];
    }
  }
  
  static remove(id: string): void {
    const existing = this.getAll();
    const filtered = existing.filter(item => item.id !== id);
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(filtered));
  }
  
  static markAsSynced(id: string): void {
    const existing = this.getAll();
    const item = existing.find(item => item.id === id);
    if (item) {
      item.synced = true;
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(existing));
    }
  }
  
  static getUnsyncedItems(): StoredMedia[] {
    return this.getAll().filter(item => !item.synced);
  }
  
  static clear(): void {
    localStorage.removeItem(this.STORAGE_KEY);
  }
}
