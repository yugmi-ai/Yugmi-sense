import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { BottomNavigation } from "@/components/bottom-navigation";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import Camera from "@/pages/camera";
import Gallery from "@/pages/gallery";
import MediaDetail from "@/pages/media-detail";
import Reports from "@/pages/reports";

function Router() {
  return (
    <div className="relative max-w-md mx-auto bg-white min-h-screen">
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/camera" component={Camera} />
        <Route path="/gallery" component={Gallery} />
        <Route path="/media/:id" component={MediaDetail} />
        <Route path="/reports" component={Reports} />
        <Route component={NotFound} />
      </Switch>
      
      {/* Bottom Navigation - shown on all pages except camera */}
      <Route path="/camera">
        {() => null}
      </Route>
      <Route>
        {() => <BottomNavigation />}
      </Route>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
